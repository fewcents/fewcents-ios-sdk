//
//  Fewcents_iOS_SDK.h
//  Fewcents-iOS-SDK
//
//  Created by Chowdhury Md Rajib  Sarwar on 12/5/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Fewcents_iOS_SDK.
FOUNDATION_EXPORT double Fewcents_iOS_SDKVersionNumber;

//! Project version string for Fewcents_iOS_SDK.
FOUNDATION_EXPORT const unsigned char Fewcents_iOS_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Fewcents_iOS_SDK/PublicHeader.h>

